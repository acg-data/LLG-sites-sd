import type { Metadata } from "next";
import { Bebas_Neue, Montserrat } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";

const bebas = Bebas_Neue({ weight: "400", subsets: ["latin"], variable: "--font-heading" });
const montserrat = Montserrat({ subsets: ["latin"], variable: "--font-body" });

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("host") ?? "savannahfrenchdrain.com";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.includes("localhost") ? "http" : "https");
  const image = `${protocol}://${host}/og.png`;
  return {
    title: "Savannah French Drain | Expert Drainage Solutions",
    description: "French drains, yard drainage, storm pipes, and drainage inspections for Savannah, Georgia. Call (912) 455-6215 for a free estimate.",
    openGraph: { title: "Savannah French Drain", description: "Drainage solutions that protect your property.", images: [{ url: image, width: 1200, height: 630 }] },
    twitter: { card: "summary_large_image", images: [image] },
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className={`${bebas.variable} ${montserrat.variable}`}>{children}</body></html>;
}
