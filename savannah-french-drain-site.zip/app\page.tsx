const services = [
  { number: "01", title: "French Drains", text: "Long-lasting, nearly invisible systems that move surface and groundwater away from your property." },
  { number: "02", title: "Exterior Drainage", text: "Custom drainage plans for foundations, lawns, beds, patios, and problem areas outside your home." },
  { number: "03", title: "Interior French Drains", text: "Perimeter drainage that helps protect basements and below-grade spaces from unwanted water." },
  { number: "04", title: "Storm Pipe Installation", text: "High-capacity underground piping installed to manage heavy Coastal Georgia rain and runoff." },
  { number: "05", title: "Drain Inspections", text: "Practical diagnosis for slow, clogged, damaged, or underperforming drainage systems." },
  { number: "06", title: "Yard Drainage", text: "Targeted solutions for standing water, soggy lawns, erosion, and unusable outdoor spaces." },
];

const areas = ["Savannah", "Pooler", "Richmond Hill", "Bloomingdale", "Tybee Island", "Georgetown", "Garden City", "Wilmington Island", "Skidaway Island", "Rincon", "Port Wentworth", "Hinesville"];

const faqs = [
  ["How do I know which drainage system I need?", "Every property moves water differently. We inspect the low spots, grading, soil, downspouts, and discharge options, then recommend the simplest system that solves the actual problem."],
  ["How long does a French drain installation take?", "Many residential projects can be completed in a few days. Larger or more complex systems may take longer; your written estimate will include a clear project schedule."],
  ["Will a French drain ruin my yard?", "We plan access carefully, contain excavation, and restore the work area when installation is complete. Most systems are discreet once finished."],
  ["Do you work on commercial properties?", "Yes. We design and install drainage solutions for both residential and commercial properties throughout the Savannah area."],
];

function Brand({ light = false }: { light?: boolean }) {
  return <span className={`brand ${light ? "brand-light" : ""}`} aria-label="Savannah French Drain"><span className="brand-mark" aria-hidden="true"><i /><b /></span><span className="brand-words"><strong>SAVANNAH</strong><em>FRENCH DRAIN</em></span></span>;
}

export default function Home() {
  return (
    <main>
      <header className="hero" id="top">
        <nav className="nav shell" aria-label="Main navigation">
          <a href="#top" className="brand-link"><Brand light /></a>
          <div className="nav-links"><a href="#services">Services</a><a href="#process">Our Process</a><a href="#areas">Service Area</a></div>
          <a className="nav-cta" href="tel:9124556215">Free Estimate <span>→</span></a>
        </nav>
        <div className="hero-inner shell">
          <div className="hero-copy">
            <p className="eyebrow light">Savannah&apos;s drainage specialists</p>
            <h1>Keep your home dry.<br /><span>Protect your foundation.</span></h1>
            <p className="hero-kicker">Expert drainage solutions. Zero guesswork.</p>
            <p className="hero-body">French drains, yard drainage, storm pipes, and foundation protection designed for the way water moves across Coastal Georgia properties.</p>
            <div className="hero-actions"><a className="button button-blue" href="tel:9124556215">Call (912) 455-6215 <span>→</span></a><a className="button button-outline" href="#services">Explore Services</a></div>
          </div>
          <div className="hero-visual">
            <img src="/project-1.jpg" alt="French drain installation with gravel and drainage pipe" />
            <div className="water-card"><span className="drop" aria-hidden="true" /><strong>Built for Savannah rain</strong><small>Proper pitch. Clean stone. Reliable flow.</small></div>
          </div>
        </div>
        <div className="hero-credentials shell" aria-label="Business credentials"><span><b>✓</b><strong>Licensed & insured</strong></span><span><b>25+</b><strong>Years of experience</strong></span><span><b>✓</b><strong>Fully in-house team</strong></span><span><b>100%</b><strong>Functionality guarantee</strong></span></div>
      </header>

      <section className="section services" id="services"><div className="shell">
        <div className="section-head split-head"><div><p className="eyebrow">What we solve</p><h2>Drainage that works.<br /><span>Protection that lasts.</span></h2></div><p>From a single soggy corner to a whole-property water problem, we design around your grade, soil, structures, and discharge point.</p></div>
        <div className="service-grid">
          {services.map((service) => <article className="service-card" key={service.title}><div className="service-number">{service.number}</div><h3>{service.title}</h3><p>{service.text}</p><a href="tel:9124556215" aria-label={`Ask about ${service.title}`}>Ask our crew <span>→</span></a></article>)}
          <article className="service-card service-callout"><div className="callout-drop" aria-hidden="true" /><h3>Not sure what your property needs?</h3><p>We&apos;ll trace the water, explain the options, and give you an honest written estimate.</p><a href="tel:9124556215">Talk to a drainage expert <span>→</span></a></article>
        </div>
      </div></section>

      <section className="project-section" aria-label="French drain projects">
        <div className="shell project-intro"><div><p className="eyebrow light">Built below the surface</p><h2>The right system starts<br />with the right path.</h2></div><p>Water always finds the low point. Our job is to give it a controlled route away from your lawn, foundation, or hardscape.</p></div>
        <div className="project-grid"><figure><img src="/project-2.jpg" alt="French drain trench and pipe installation" /><figcaption><span>01</span> Gravel French drain</figcaption></figure><figure className="project-wide"><img src="/project-3.webp" alt="Exterior foundation French drain installation" /><figcaption><span>02</span> Foundation drainage</figcaption></figure><figure><img src="/project-1.jpg" alt="Completed French drain trench before covering" /><figcaption><span>03</span> Yard water control</figcaption></figure></div>
      </section>

      <section className="section reviews"><div className="shell">
        <div className="section-head centered"><p className="eyebrow">Local homeowner feedback</p><h2>Five-star service.<br /><span>Drier properties.</span></h2><p>Clear communication, careful work, and drainage systems built to do their job.</p></div>
        <div className="review-grid">
          <article><div className="stars">★★★★★</div><p>“Excellent comprehensive service from very experienced professionals — and affordable!”</p><div className="reviewer"><b>M</b><span><strong>Mike Jackson</strong><small>Savannah-area customer</small></span></div></article>
          <article><div className="stars">★★★★★</div><p>“So professional, courteous, and quick!”</p><div className="reviewer"><b>J</b><span><strong>Jefferson Gilbert</strong><small>Savannah-area customer</small></span></div></article>
          <article><div className="stars">★★★★★</div><p>“Great company.”</p><div className="reviewer"><b>T</b><span><strong>Terrell Vanhorne</strong><small>Savannah-area customer</small></span></div></article>
        </div>
      </div></section>

      <section className="section areas" id="areas"><div className="shell areas-grid"><div className="area-copy"><p className="eyebrow">Where we work</p><h2>Coastal Georgia&apos;s<br /><span>local drainage team.</span></h2><p>Based in Savannah and serving homes and businesses across Chatham County and the surrounding region.</p><a className="text-link" href="tel:9124556215">Check your address with our crew <span>→</span></a></div><div className="area-list">{areas.map((area, index) => <span key={area}><b>{String(index + 1).padStart(2, "0")}</b>{area}</span>)}</div></div></section>

      <section className="process" id="process"><div className="shell">
        <div className="section-head centered light-head"><p className="eyebrow light">Our process</p><h2>Simple, clear, and built<br />around your property.</h2><p>Three steps from standing water to a drainage system designed to keep it moving.</p></div>
        <div className="process-grid"><article><b>01</b><span className="process-line" /><h3>Tell us what&apos;s happening.</h3><p>Call and describe the pooling, runoff, erosion, or moisture you are seeing.</p></article><article><b>02</b><span className="process-line" /><h3>Free on-site estimate.</h3><p>We walk the property, trace the water, and explain the recommended system.</p></article><article><b>03</b><span className="process-line" /><h3>We install it right.</h3><p>Our in-house crew completes the work with proven materials and a clean finish.</p></article></div>
      </div></section>

      <section className="section faq" id="faq"><div className="shell faq-grid"><div><p className="eyebrow">Good to know</p><h2>Frequently asked<br /><span>questions.</span></h2><p className="faq-intro">Have a question that is not listed? Call our team and we&apos;ll talk it through.</p><a className="text-link" href="tel:9124556215">Call (912) 455-6215 <span>→</span></a></div><div className="accordion">{faqs.map(([question, answer]) => <details key={question}><summary>{question}<b>+</b></summary><p>{answer}</p></details>)}</div></div></section>

      <section className="final-cta" id="contact"><div className="cta-pattern" aria-hidden="true" /><div className="shell cta-content"><div><p className="eyebrow light">Ready to protect your property?</p><h2>Stop fighting the water.<br />Start with a free estimate.</h2><p>No pressure. No subcontractors. Just an experienced local crew and an honest drainage plan.</p></div><div className="cta-actions"><a className="button button-white" href="tel:9124556215">Call (912) 455-6215 <span>→</span></a><a href="mailto:info@savannahfrenchdrain.com">info@savannahfrenchdrain.com</a></div></div></section>

      <footer className="footer"><div className="shell footer-grid"><div><Brand light /><p>Drainage solutions that protect your property across Savannah and Coastal Georgia.</p><a href="tel:9124556215">(912) 455-6215</a></div><div><h3>Services</h3><a href="#services">French Drains</a><a href="#services">Yard Drainage</a><a href="#services">Storm Pipes</a><a href="#services">Drain Inspections</a></div><div><h3>Company</h3><a href="#process">Our Process</a><a href="#areas">Service Area</a><a href="#faq">FAQs</a><a href="mailto:info@savannahfrenchdrain.com">Contact</a></div><div className="footer-note"><span>Built to protect.</span><strong>BUILT TO LAST.</strong><small>Licensed & insured<br />Savannah, Georgia</small></div></div><div className="shell footer-bottom"><span>© 2026 Savannah French Drain.</span><a href="#top">Back to top ↑</a></div></footer>
    </main>
  );
}
