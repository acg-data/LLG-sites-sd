const services = [
  {
    number: "01",
    title: "Tree Trimming & Pruning",
    description:
      "Shape healthier, safer trees with thoughtful pruning performed by experienced tree-care professionals.",
    image: "https://irp.cdn-website.com/b554996e/dms3rep/multi/opt/Poway-Tree+Service-6-1104w.jpeg",
    href: "https://www.powaytreeservicepros.com/tree-trimming-and-pruning",
    bullets: ["Crown thinning", "Deadwood removal", "Structural pruning"],
  },
  {
    number: "02",
    title: "Tree Removal & Stump Grinding",
    description:
      "Careful removal for hazardous, damaged, or unwanted trees—followed by a clean, usable yard.",
    image: "https://irp.cdn-website.com/b554996e/dms3rep/multi/opt/Poway-Tree+Service-5-569f5e7a-1104w.jpeg",
    href: "https://www.powaytreeservicepros.com/tree-removal-and-stump-grinding",
    bullets: ["Hazard assessment", "Controlled removal", "Stump grinding"],
  },
  {
    number: "03",
    title: "Palm Tree Service",
    description:
      "Specialized palm trimming and maintenance that keeps Southern California landscapes clean and beautiful.",
    image: "https://irp.cdn-website.com/b554996e/dms3rep/multi/opt/Poway-Tree+Service-7-1104w.jpeg",
    href: "https://www.powaytreeservicepros.com/palm-tree-service",
    bullets: ["Palm pruning", "Health inspections", "Preventive care"],
  },
];

const reviews = [
  {
    quote:
      "We were very pleased with the job that was done on our front lawn. Poway Tree Service Pros removed a large tree from our yard in a timely fashion and cleaned up after themselves when they were finished. We couldn’t be happier with the outcome! Highly recommend them for any tree service needs!",
    author: "Telly M.",
  },
  {
    quote:
      "Poway Tree Service Pros did an amazing job pruning my trees and shrubs in preparation for winter weather. They were extremely professional throughout the entire process, showed up on time as scheduled, and made sure that everything was left looking neat and tidy afterward. Highly recommend them to anyone looking for quality tree care services!",
    author: "Allen L.",
  },
  {
    quote:
      "I had a problematic tree in my backyard that had been growing for years and I was worried about its potential risks if left untreated, so I called Poway Tree Service Pros for help. They came out the same day and did a fantastic job removing it quickly and efficiently with no mess left behind! Would use their services again if needed!",
    author: "Iverson H.",
  },
];

function Brand() {
  return (
    <a className="brand" href="#top" aria-label="Poway Tree Service Pros home">
      <span className="brand-mark" aria-hidden="true">♣</span>
      <span className="brand-copy">
        <strong>POWAY</strong>
        <span>TREE SERVICE PROS</span>
        <small>Expert care. Beautiful results.</small>
      </span>
    </a>
  );
}

export default function Home() {
  return (
    <main id="top">
      <header className="site-header">
        <div className="shell header-inner">
          <Brand />
          <nav className="desktop-nav" aria-label="Primary navigation">
            <a href="#services">Services</a>
            <a href="#about">About</a>
            <a href="#reviews">Reviews</a>
            <a href="#contact">Contact</a>
          </nav>
          <a className="phone-button" href="tel:858-240-2012">
            <span aria-hidden="true">☎</span> 858-240-2012
          </a>
          <details className="mobile-nav">
            <summary aria-label="Open navigation">Menu</summary>
            <nav aria-label="Mobile navigation">
              <a href="#services">Services</a>
              <a href="#about">About</a>
              <a href="#reviews">Reviews</a>
              <a href="#contact">Contact</a>
            </nav>
          </details>
        </div>
      </header>

      <section className="hero">
        <div className="hero-overlay" />
        <div className="shell hero-grid">
          <div className="hero-copy">
            <div className="trust-pills">
              <span>★ Local Poway tree experts</span>
              <span>✓ Licensed, bonded & insured</span>
            </div>
            <p className="eyebrow">ROOTED IN CARE. BUILT TO LAST.</p>
            <h1>
              Poway&apos;s <em>trusted tree care</em> professionals
            </h1>
            <p className="hero-lede">
              Reliable trimming, removal, stump grinding, and palm care for homes and businesses across Poway, California.
            </p>
            <div className="hero-actions">
              <a className="primary-button" href="tel:858-240-2012">Call now: 858-240-2012</a>
              <a className="ghost-button" href="#contact">Free estimate <span>→</span></a>
            </div>
            <ul className="hero-checks" aria-label="Popular services">
              <li>Tree removal</li>
              <li>Tree trimming</li>
              <li>Stump grinding</li>
            </ul>
          </div>

          <form className="estimate-card" id="contact" action="https://www.powaytreeservicepros.com/contact-us" method="get">
            <p className="form-kicker">Get started today</p>
            <h2>Request your <span>free estimate</span></h2>
            <p>No obligation. Just honest advice and clear next steps.</p>
            <div className="form-grid">
              <label>
                Name *
                <input name="name" autoComplete="name" placeholder="Your full name" required />
              </label>
              <label>
                Phone *
                <input name="phone" type="tel" autoComplete="tel" placeholder="(858) 240-2012" required />
              </label>
            </div>
            <label>
              Email
              <input name="email" type="email" autoComplete="email" placeholder="you@example.com" />
            </label>
            <label>
              Service needed
              <select name="service" defaultValue="">
                <option value="" disabled>Select a service</option>
                <option>Tree Trimming & Pruning</option>
                <option>Tree Removal & Stump Grinding</option>
                <option>Palm Tree Service</option>
                <option>Other</option>
              </select>
            </label>
            <label>
              Project details
              <textarea name="details" rows={3} placeholder="Tell us about your trees, property, or timeline." />
            </label>
            <button type="submit">Send my request <span>→</span></button>
            <small>Or call for immediate assistance: 858-240-2012</small>
          </form>
        </div>
      </section>

      <section className="credentials" aria-label="Company credentials">
        <div className="shell credential-grid">
          <article><b>20+</b><span>Years of experience</span></article>
          <article><b>100%</b><span>Licensed & insured</span></article>
          <article><b>Local</b><span>Poway-based service</span></article>
          <article><b>Clean</b><span>Respectful job sites</span></article>
        </div>
      </section>

      <section className="section services" id="services">
        <div className="shell">
          <div className="section-heading">
            <div>
              <p className="eyebrow dark">HEALTHY TREES. BEAUTIFUL SPACES.</p>
              <h2>Tree care made <em>simple</em></h2>
            </div>
            <p>From seasonal maintenance to complex removals, our experienced team approaches every property with safety, precision, and respect.</p>
          </div>
          <div className="service-grid">
            {services.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-image" style={{ backgroundImage: `url(${service.image})` }}>
                  <span>{service.number}</span>
                </div>
                <div className="service-content">
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <ul>{service.bullets.map((item) => <li key={item}>✓ {item}</li>)}</ul>
                  <a href={service.href}>Explore service <span>→</span></a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="care-strip">
        <div className="shell care-grid">
          <span>♣ Tree removal</span>
          <span>✂ Tree trimming</span>
          <span>◉ Stump grinding</span>
          <span>↟ Palm care</span>
          <span>✓ Safety first</span>
        </div>
      </section>

      <section className="section about" id="about">
        <div className="shell about-grid">
          <div className="about-image" role="img" aria-label="Professional tree care in Poway">
            <div className="experience-badge"><strong>Poway</strong><span>local tree care</span></div>
          </div>
          <div className="about-copy">
            <p className="eyebrow dark">WHY POWAY TREE SERVICE PROS</p>
            <h2>Expert care for every <em>branch and root</em></h2>
            <p>Trees bring life, shade, and value to your property. Our team helps protect that investment with thoughtful recommendations, dependable service, and careful work from the first cut to the final cleanup.</p>
            <div className="feature-list">
              <article><span>01</span><div><h3>Safety comes first</h3><p>Every project begins with a careful look at the tree, the property, and the safest path forward.</p></div></article>
              <article><span>02</span><div><h3>Local knowledge</h3><p>We understand Poway landscapes, palms, weather, and the tree-care challenges unique to our area.</p></div></article>
              <article><span>03</span><div><h3>Respectful service</h3><p>Clear communication, prompt arrival, and a clean finish are part of every job.</p></div></article>
            </div>
            <a className="text-link" href="https://www.powaytreeservicepros.com/about-us">Get to know our team <span>→</span></a>
          </div>
        </div>
      </section>

      <section className="section reviews" id="reviews">
        <div className="shell">
          <div className="reviews-header">
            <div>
              <p className="eyebrow">LOCAL PROOF</p>
              <h2>What our customers say</h2>
            </div>
            <div className="rating"><strong>5.0</strong><span>★★★★★<small>Customer testimonials</small></span></div>
          </div>
          <div className="review-grid">
            {reviews.map((review, index) => (
              <article className="review-card" key={review.author}>
                <div className="stars" aria-label="5 out of 5 stars">★★★★★</div>
                <blockquote>“{review.quote}”</blockquote>
                <footer><span>{String(index + 1).padStart(2, "0")}</span><strong>{review.author}</strong></footer>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="final-cta">
        <div className="shell cta-inner">
          <div>
            <p className="eyebrow">EXPERT CARE. BEAUTIFUL RESULTS.</p>
            <h2>Let&apos;s take care of your trees.</h2>
          </div>
          <div className="cta-actions">
            <a className="primary-button" href="tel:858-240-2012">Call 858-240-2012</a>
            <a className="ghost-button" href="#contact">Request an estimate →</a>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="shell footer-grid">
          <div><Brand /><p>Professional tree trimming, removal, stump grinding, and palm care in Poway, California.</p></div>
          <div><h3>Services</h3><a href="#services">Tree trimming</a><a href="#services">Tree removal</a><a href="#services">Stump grinding</a><a href="#services">Palm care</a></div>
          <div><h3>Company</h3><a href="#about">About us</a><a href="#reviews">Reviews</a><a href="#contact">Free estimate</a></div>
          <div><h3>Contact</h3><a href="tel:858-240-2012">858-240-2012</a><span>Poway, CA 92064</span><span>United States</span></div>
        </div>
        <div className="shell footer-bottom"><span>© 2026 Poway Tree Service Pros</span><span>Licensed, bonded & insured</span></div>
      </footer>
    </main>
  );
}
