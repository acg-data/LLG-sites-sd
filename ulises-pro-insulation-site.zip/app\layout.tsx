import type { Metadata } from "next";
import "./globals.css";
import "./form.css";

export const metadata: Metadata = {
  title: "Ulises Pro Insulation | Beaverton, OR",
  description: "Attic, crawl space and blown-in insulation services in Beaverton and the Portland metro area.",
  icons: {
    icon: "/ulises-logo.png",
  },
  openGraph: {
    title: "Ulises Pro Insulation | Beaverton, OR",
    description: "Better insulation. Lower bills. Greater comfort.",
    images: [{ url: "/og.png", width: 1792, height: 1024, alt: "Ulises Pro Insulation in Beaverton, Oregon" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Ulises Pro Insulation | Beaverton, OR",
    description: "Better insulation. Lower bills. Greater comfort.",
    images: ["/og.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );
}
