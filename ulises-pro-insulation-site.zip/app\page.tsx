const services = [
  { icon: "⌂", title: "Attic Insulation", text: "Keep heat where it belongs with a properly sealed and insulated attic.", image: "/attic.png" },
  { icon: "▤", title: "Crawl Space Insulation", text: "Protect your floors from moisture, cold, and energy loss year-round.", image: "/crawlspace.png" },
  { icon: "✦", title: "Blown-In Insulation", text: "Fill gaps evenly and efficiently for consistent whole-home comfort.", image: "/blown-in.jpeg" },
  { icon: "↺", title: "Insulation Removal", text: "Safe, thorough removal of damaged or outdated insulation materials.", image: "/project-main.png" },
  { icon: "◈", title: "Drill & Fill", text: "Upgrade existing walls with minimal disruption to your finished spaces.", image: "/crew.png" },
];

const areas = ["Beaverton", "Hillsboro", "Aloha", "Tigard", "Sherwood", "Oregon City", "West Linn", "Lake Oswego", "Wilsonville", "Newberg"];

const originalReviews = [
  ["Jim Griffin", "My son, after pricing around and talking with different insulation company reps, settled on Ulises Pro Insulation and was well pleased with the finished results. I then selected Ulises' company and also am very happy with the quality of the work. The owner was easy to work with, was not pushy, the workers were very competent, and the price was right!"],
  ["Linda Fogerson", "This is a great crew. They correctly diagnosed the problem and were very efficient with installation. We had three bids and his was the most realistic and on point in terms of solving the problem. We are now nice and warm in a section of the house that was just too cold before. So happy we went with them!"],
  ["James Casavan", "Ulises had a great, courteous, incredibly hard-working crew insulate my attic and crawlspace, seal ducts, wrap pipes, and more. I'd highly recommend them. Five stars for sure!"],
  ["Aida Calderon", "I got my house insulated both the attic and the crawl space from this insulation company and I'm very happy with the service. They air sealed both spaces, filling up all the cracks where air may go through. Very respectful and courteous. These guys didn't fail to impress as they completed the work in little time and charged a very affordable price for it! Perfect example of what a great service should be like!"],
  ["Catherine Hoffman", "Great company. I called after all our old insulation was removed. Since cold weather was forecast, I asked how quickly he could get new insulation in. Ulises was great: got it done in days and before the weather hit. I highly recommend the company."],
  ["Howard Graitzer", "I had UPI do attic insulation and they were excellent. On time, respectful, cleaned up well. Job was done correctly. Very high recommendation."],
];

const reviewsArchive = [
  ["Jim G.", "The owner was easy to work with, the workers were very competent, and the price was right. We’re very happy with the quality of the work."],
  ["Linda F.", "They correctly diagnosed the problem and were very efficient. We are now nice and warm in a section of the house that was just too cold before."],
  ["James C.", "A great, courteous, incredibly hard-working crew. They insulated my attic and crawlspace, sealed ducts and wrapped pipes. Five stars for sure!"],
];

export default function Home() {
  return (
    <main id="top">
      <nav className="nav shell" aria-label="Main navigation">
        <a className="brand" href="#top" aria-label="Ulises Pro home"><img src="/ulises-logo.png" alt="Ulises Pro Insulation" /></a>
        <div className="navlinks"><a href="#services">Services</a><a href="#about">About Us</a><a href="#areas">Service Area</a></div>
        <a className="button small" href="tel:9713146266">Get a Free Estimate</a>
      </nav>

      <section className="hero">
        <div className="shell heroGrid">
          <div className="heroCopy">
            <p className="eyebrow light">Beaverton’s local insulation specialists</p>
            <h1>Better insulation.<br /><span>Lower bills.</span><br />Greater comfort.</h1>
            <p className="lead">Attic, crawl space, and blown-in insulation installed by an experienced local crew serving Beaverton and the greater Portland area.</p>
            <div className="actions"><a className="button" href="tel:9713146266">Call 971-314-6266 <b>→</b></a><a className="textLink" href="#services">See Services</a></div>
          </div>
          <form className="estimateForm" action="mailto:info@ulisesproinsulationcontractorbeavertonor.com" method="post" encType="text/plain">
            <div className="formHead"><span>Free estimate</span><h2>Tell us about your project.</h2><p>Share a few details and our local crew will help you find the right insulation solution.</p></div>
            <div className="formRow"><label>Full name<input name="Name" type="text" placeholder="Your name" autoComplete="name" required /></label><label>Phone number<input name="Phone" type="tel" placeholder="(971) 000-0000" autoComplete="tel" required /></label></div>
            <label>Email address<input name="Email" type="email" placeholder="you@email.com" autoComplete="email" required /></label>
            <label>Desired service<select name="Service" defaultValue=""><option value="" disabled>Select a service</option><option>Attic Insulation</option><option>Crawl Space Insulation</option><option>Blown-In Insulation</option><option>Insulation Removal</option><option>Drill & Fill</option><option>Other</option></select></label>
            <label>Project details<textarea name="Project details" placeholder="Tell us what is happening in your home" rows={3}></textarea></label>
            <button className="button formButton" type="submit">Request My Free Estimate <b>→</b></button>
            <small>Submitting opens your email app with these details addressed to Ulises Pro.</small>
          </form>
        </div>
        <div className="trust shell"><span>✦ <b>Licensed & insured</b></span><span>✦ <b>Local experienced crew</b></span><span>✦ <b>Free estimates</b></span></div>
      </section>

      <section className="section shell" id="services">
        <p className="eyebrow">What we do</p><h2>Comfort built into<br />every corner of your home.</h2>
        <p className="intro">One dependable crew for insulation upgrades, replacements, and hard-to-reach spaces.</p>
        <div className="serviceGrid">{services.map((s) => <a className="serviceCard" href="tel:9713146266" key={s.title}><div className="serviceIcon">{s.icon}</div><h3>{s.title}</h3><p>{s.text}</p><span>Ask about this service →</span></a>)}
          <a className="helpCard" href="tel:9713146266"><b>?</b><h3>Not sure what your home needs?</h3><p>We’ll inspect the space, explain your options, and give you an honest estimate.</p><span>Talk to our crew →</span></a>
        </div>
      </section>

      <section className="work" id="about"><div className="shell"><p className="eyebrow light">Real work. Real homes.</p><h2>Insulation done right<br />across Beaverton.</h2><div className="gallery"><img src="/project-main.png" alt="Ulises Pro insulation project" /><img src="/attic.png" alt="Attic insulation project" /><img src="/crawlspace.png" alt="Crawl space insulation project" /><img src="/blown-in.jpeg" alt="Blown-in insulation project" /></div></div></section>

      <section className="section reviews"><div className="shell"><p className="eyebrow">Local homeowner reviews</p><h2>Warm homes.<br />Happy customers.</h2><div className="reviewGrid">{originalReviews.map(([name,quote])=><article key={name}><div className="stars">★★★★★</div><p>“{quote}”</p><div className="reviewer"><b>{name[0]}</b><span><strong>{name}</strong><small>Oregon homeowner</small></span></div></article>)}</div></div></section>

      <section className="areas" id="areas"><div className="shell areaGrid"><div><p className="eyebrow light">Where we work</p><h2>Your local insulation<br />team in Oregon.</h2><p>Based in Beaverton and helping homeowners throughout the Portland metro area.</p><a className="button" href="tel:9713146266">Check availability →</a></div><div className="areaList">{areas.map(a=><span key={a}>{a}</span>)}</div></div></section>

      <section className="section process shell"><p className="eyebrow">Our process</p><h2>Simple, clear, and<br />built around your home.</h2><div className="steps"><article><b>01</b><h3>Call for a free estimate.</h3><p>Tell us about your home and the comfort issues you’re noticing.</p></article><article><b>02</b><h3>We assess your space.</h3><p>Our crew checks the area and recommends the right solution.</p></article><article><b>03</b><h3>We install it right.</h3><p>Clean, efficient installation with quality materials and careful workmanship.</p></article></div></section>

      <section className="cta" id="contact"><div className="shell"><img src="/ulises-logo.png" alt="Ulises Pro Insulation" /><p className="eyebrow light">Ready for a more comfortable home?</p><h2>Get your free insulation<br />estimate today.</h2><p>No pressure. Just clear answers from a local insulation crew.</p><a className="button" href="tel:9713146266">Call 971-314-6266 →</a></div></section>

      <footer><div className="shell footerGrid"><div><img src="/ulises-logo.png" alt="Ulises Pro Insulation" /><p>Better insulation. Lower bills. Greater comfort.</p><a href="tel:9713146266">971-314-6266</a></div><div><h3>Services</h3><a href="#services">Attic Insulation</a><a href="#services">Crawl Space Insulation</a><a href="#services">Blown-In Insulation</a><a href="#services">Insulation Removal</a></div><div><h3>Company</h3><a href="#about">About Us</a><a href="#areas">Service Area</a><a href="tel:9713146266">Free Estimate</a></div></div><div className="shell copyright">© 2026 Ulises Pro Insulation. Beaverton, Oregon.</div></footer>
    </main>
  );
}
