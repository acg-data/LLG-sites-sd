const services = [
  ["01", "Landscape design", "A complete plan shaped around your home, lifestyle and the Texas climate.", "https://pristinelandscapingtx.com/img/svc-design.jpg"],
  ["02", "Patios & decks", "Comfortable outdoor rooms built for gathering, dining and unwinding.", "https://pristinelandscapingtx.com/img/svc-patios.jpg"],
  ["03", "Water features", "Natural-looking movement and sound that turn a yard into a retreat.", "https://pristinelandscapingtx.com/img/svc-water.jpg"],
  ["04", "Outdoor kitchens", "Purpose-built cooking and entertaining spaces for life outside.", "https://pristinelandscapingtx.com/img/svc-kitchen.jpg"],
];

const reviews = [
  ["Alice Wagner", "26 days ago", "An excellent landscaping group!  We are so happy with the results of a beautiful design, responsibly executed and incredibly easy to work with. I would recommend this landscaping team all day long. They did exactly what we wanted, communicated well and are all very talented. I can’t say enough good things about this company."],
  ["Janine Perez", "4 months ago", "Pristine Landscaping is one of our clients, it's always a pleasure to work with them on their projects, VaVia Dumpsters"],
  ["Kate Incremona", "9 months ago", "We had such a great experience working with this landscaping company! Greg and his team were amazing from start to finish—friendly, professional, and so easy to work with. Greg came up with a beautiful design that fit perfectly within our budget and was always willing to adjust and accommodate as needed.\n\nHe’s been incredibly supportive with any questions we’ve had and quick to check in, which made the whole process stress-free and enjoyable. The project was completed quickly with minimal disruption, and the results are absolutely stunning.\n\nOur yard looks gorgeous—the plant choices are perfect, the rock color ties everything together beautifully, and the overall design turned out even better than we imagined. You can tell the entire crew takes real pride in their work; they were respectful, hardworking, and detail-oriented throughout the process.\n\nWe couldn’t be happier with how everything turned out and highly recommend this company to anyone looking for thoughtful design, great communication, and exceptional results."],
  ["Hadley", "9 months ago", "We are repeat customers.  Gregg, Manuel and their crew did a great job with our chopped block, mulching and planting of flowers. We give this company 5 stars again for excellent service. A++"],
  ["Tara Wiatrek", "9 months ago", "So many compliments! We absolutely love our new landscaping! Pristine listened to our vision and not only did they help bring it to life, they made it even better. The company was very professional, on time and cleaned up daily. There was great communication throughout the process. Where we once had a shady spot where nothing would grow, there is now a lovely paver patio. The yard is full of lovely native plants. We couldn’t be more pleased and we have had so many compliments about our yard. We highly recommend Pristine Landscaping."],
  ["Dodie Mac", "10 months ago", "Pristine Landscaping did a beautiful job! Owner Gregg was excellent and informative with all aspects of this project. I knew what I wanted to add in the back yard but knew very little about the plants, landscaping throughout the yard. I now have an orchard, pollinator garden,  area for swing set and they poured a slab for my gazebo. And more! I highly recommend Pristine Landscaping!"],
  ["Melissa Dagne", "10 months ago", "The crew that came out to do the work was polite and respectful throughout the process. They worked hard to complete the job and made sure the wall was built solid and sturdy. Communication was prompt, and they showed up as scheduled. I appreciate their efforts and the time they put into finishing the project."],
  ["Jess Gearhart", "10 months ago", "Gregg and his team did an amazing job on our retaining wall around our above ground pool! I would highly recommend!"],
];

function LeafMark() {
  return <span className="leaf" aria-hidden="true"><i /><i /><i /></span>;
}

export default function Home() {
  return (
    <main>
      <div className="topbar"><span>Beautiful outdoors. Expert care. Lasting impressions.</span><a href="tel:2106254368">Call (210) 625-4368</a></div>
      <header>
        <a className="brand" href="#top" aria-label="Pristine Landscaping home"><LeafMark /><span><b>PRISTINE</b><small>LANDSCAPING TX</small></span></a>
        <nav aria-label="Main navigation"><a href="#services">Services</a><a href="#difference">About</a><a href="#work">Projects</a><a href="#reviews">Reviews</a></nav>
        <a className="headerCta" href="#quote">Free consultation <span>↗</span></a>
      </header>

      <section className="hero" id="top">
        <div className="heroShade" />
        <div className="heroCopy">
          <p className="eyebrow light">San Antonio’s landscape transformation experts</p>
          <h1>Designed for life.<br /><em>Built to thrive.</em></h1>
          <p className="intro">Thoughtful landscape design and masterful construction—created for the way you want to live outside.</p>
          <div className="actions"><a className="btn tan" href="#quote">Get a free quote <span>→</span></a><a className="textLink" href="#work">Explore our work <span>↘</span></a></div>
        </div>
        <div className="heroStamp"><LeafMark /><span><b>Since 2006</b>Serving San Antonio</span></div>
        <div className="serviceStrip" aria-label="Featured services">
          {["Landscape design", "Outdoor living", "Hardscapes", "Irrigation", "Tree & shrub care"].map((item, i) => <a key={item} href="#services"><span>0{i + 1}</span>{item}</a>)}
        </div>
      </section>

      <section className="statement" id="difference">
        <div><p className="eyebrow">The Pristine difference</p><h2>Your outdoors should feel<br />as good as <em>home.</em></h2></div>
        <div className="statementBody"><p>A great landscape is more than beautiful. It welcomes you outside, works with the way you live and gets better with time.</p><p>Led by a licensed landscape architect, our team brings every detail together—from the first sketch to the final stone.</p><a className="arrowLink" href="#quote">Plan your transformation <span>→</span></a></div>
      </section>

      <section className="services" id="services">
        <div className="sectionHead"><div><p className="eyebrow">Full-service outdoor transformations</p><h2>One team. Every detail.<br /><em>One beautiful result.</em></h2></div><p>Custom environments designed and built for lasting enjoyment.</p></div>
        <div className="serviceGrid">
          {services.map(([num, title, copy, image]) => <article key={title} className="serviceCard"><img src={image} alt={title} /><div className="cardFade" /><span className="num">{num}</span><div className="cardCopy"><h3>{title}</h3><p>{copy}</p><a href="#quote" aria-label={`Plan ${title}`}>↗</a></div></article>)}
        </div>
        <div className="moreServices"><span>More ways we can help</span><a href="#quote">Fireplaces & fire pits</a><a href="#quote">Fences & retaining walls</a><a href="#quote">Decorative concrete</a><a href="#quote">Irrigation & sprinklers</a></div>
      </section>

      <section className="work" id="work">
        <div className="workImage"><img src="https://pristinelandscapingtx.com/img/hero.jpg" alt="Custom San Antonio landscape with a stone walkway and lush planting" /><div className="imageNote">A landscape made<br />to live beautifully.</div></div>
        <div className="workCopy"><p className="eyebrow light">Expertise from concept to completion</p><h2>We see the whole<br /><em>picture.</em></h2><p>Outdoor spaces work best when every element belongs. Our landscape architect considers flow, scale, materials, drainage, planting and the realities of the Texas climate as one cohesive design.</p><ul><li><b>01</b><span><strong>True design expertise</strong>Led by a licensed landscape architect—not a salesperson with a clipboard.</span></li><li><b>02</b><span><strong>Master craftsmen on site</strong>Experienced crews who care about every line, joint and planting.</span></li><li><b>03</b><span><strong>Built to last in Texas</strong>Materials and plants chosen to thrive here for years to come.</span></li></ul><a className="btn tan" href="#quote">Start your project <span>→</span></a></div>
      </section>

      <section className="stats"><div><b>20</b><span>Years serving<br />San Antonio</span></div><div><b>1</b><span>Expert team from<br />design to build</span></div><div><b>5★</b><span>Google-reviewed<br />local service</span></div><div><b>100%</b><span>Focused on lasting<br />customer value</span></div></section>

      <section className="reviews" id="reviews">
        <div className="sectionHead"><div><p className="eyebrow">Kind words, beautiful spaces</p><h2>What our clients<br /><em>are saying.</em></h2></div><div className="googleMark"><span className="g">G</span><span><b>5-star experiences</b>Published Google reviews</span></div></div>
        <div className="reviewGrid">
          {reviews.map(([name, date, text]) => <article className="review" key={name}><div className="stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>{text}</blockquote><footer><span className="avatar">{name[0]}</span><span><b>{name}</b><small>{date} · Google</small></span></footer></article>)}
        </div>
      </section>

      <section className="process">
        <p className="eyebrow light">Simple from start to finish</p><h2>Your vision. Our process.<br /><em>A place you’ll love.</em></h2>
        <div className="steps"><article><span>01</span><h3>Walk & listen</h3><p>We meet at your property, learn how you want to use it and understand your goals.</p></article><article><span>02</span><h3>Design & define</h3><p>Our landscape architect develops a thoughtful concept and clear written quote.</p></article><article><span>03</span><h3>Build it right</h3><p>Our in-house team brings the plan to life and stays until every detail feels right.</p></article></div>
      </section>

      <section className="quote" id="quote">
        <div className="quoteIntro"><p className="eyebrow">Free on-site consultation</p><h2>Let’s create your<br /><em>outdoor oasis.</em></h2><p>Tell us a little about your project. We’ll be in touch to schedule a relaxed, no-obligation conversation at your property.</p><div className="contactLine"><span>Prefer to talk?</span><a href="tel:2106254368">(210) 625-4368</a></div></div>
        <form action="mailto:info@pristinelandscapingtx.com" method="post" encType="text/plain"><div className="fieldRow"><label>First name<input name="first-name" required /></label><label>Last name<input name="last-name" required /></label></div><div className="fieldRow"><label>Email<input name="email" type="email" required /></label><label>Phone<input name="phone" type="tel" required /></label></div><label>What can we help you create?<select name="project"><option>Complete landscape transformation</option><option>Patio or outdoor living</option><option>Water feature</option><option>Retaining wall or hardscape</option><option>Irrigation or planting</option></select></label><label>Tell us about your vision<textarea name="details" rows={4} /></label><button className="btn green" type="submit">Request my consultation <span>→</span></button><small>By submitting, you agree to be contacted about your project.</small></form>
      </section>

      <footer className="footer"><div className="footerBrand"><a className="brand inverse" href="#top"><LeafMark /><span><b>PRISTINE</b><small>LANDSCAPING TX</small></span></a><p>Premium service.<br />Pristine results.</p></div><div><b>Explore</b><a href="#services">Services</a><a href="#difference">Our difference</a><a href="#work">Projects</a><a href="#reviews">Reviews</a></div><div><b>Contact</b><a href="tel:2106254368">(210) 625-4368</a><a href="mailto:info@pristinelandscapingtx.com">Email our team</a><span>San Antonio, Texas</span></div><div className="footerNote"><b>Licensed & insured</b><p>Proudly serving San Antonio and surrounding areas since 2006.</p></div><small className="copyright">© 2026 Pristine Landscaping TX. All rights reserved.</small></footer>
    </main>
  );
}
