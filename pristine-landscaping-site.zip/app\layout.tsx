import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pristine Landscaping TX | San Antonio Landscape Design",
  description: "Premium landscape design, hardscaping, water features and outdoor living spaces in San Antonio, Texas. Serving local homeowners since 2006.",
  openGraph: {
    title: "Pristine Landscaping TX",
    description: "Designed for life. Built to thrive.",
    images: [{ url: "/og.png", width: 1674, height: 941, alt: "Pristine Landscaping TX — Designed for life. Built to thrive." }],
  },
  twitter: { card: "summary_large_image", images: ["/og.png"] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
