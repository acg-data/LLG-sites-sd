(function () {
  var nav = document.getElementById('nav');
  var toggle = document.querySelector('.menu-toggle');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('[data-tab]').forEach(function (button) {
    button.addEventListener('click', function () {
      var parent = button.closest('.mission-panel');
      parent.querySelectorAll('[data-tab]').forEach(function (item) { item.classList.remove('active'); });
      parent.querySelectorAll('.tab-panel').forEach(function (panel) { panel.hidden = true; });
      button.classList.add('active');
      parent.querySelector('#' + button.dataset.tab).hidden = false;
    });
  });

  document.querySelectorAll('.quote-form').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      form.querySelector('.form-success').style.display = 'block';
      form.reset();
    });
  });
})();
