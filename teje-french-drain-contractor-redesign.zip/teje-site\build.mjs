import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { extname, join } from 'node:path';

const root = process.cwd();
const pages = readdirSync(root).filter((file) => extname(file) === '.html');
const errors = [];

for (const page of pages) {
  const html = readFileSync(join(root, page), 'utf8');
  if (/https?:\/\/(www\.)?tejefrenchdraincontractor\.com/i.test(html)) {
    errors.push(`${page}: contains a link to the original website`);
  }
  for (const match of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
    const target = match[1];
    if (/^(?:https?:|tel:|mailto:|#)/.test(target)) continue;
    const file = target.split('#')[0].split('?')[0];
    if (file && !existsSync(join(root, file))) errors.push(`${page}: missing ${file}`);
  }
}

const css = readFileSync(join(root, 'styles.css'), 'utf8');
for (const match of css.matchAll(/url\(["']?([^"')]+)["']?\)/g)) {
  const target = match[1];
  if (!/^https?:/.test(target) && !existsSync(join(root, target))) errors.push(`styles.css: missing ${target}`);
}

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}

const report = `Build verified ${pages.length} HTML pages, all local links and assets, and no links to the original domain.\n`;
writeFileSync(join(root, 'build-report.txt'), report, 'utf8');
console.log(report.trim());
