const nav = document.querySelector('.site-nav');
const toggle = document.querySelector('.nav-toggle');
const links = document.querySelector('.nav-links');

const closeMenu = () => {
  toggle?.setAttribute('aria-expanded', 'false');
  links?.classList.remove('open');
  document.body.classList.remove('nav-open');
};

toggle?.addEventListener('click', () => {
  const open = toggle.getAttribute('aria-expanded') === 'true';
  toggle.setAttribute('aria-expanded', String(!open));
  links.classList.toggle('open', !open);
  document.body.classList.toggle('nav-open', !open);
});

links?.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
window.addEventListener('resize', () => { if (window.innerWidth > 820) closeMenu(); });
window.addEventListener('scroll', () => nav?.classList.toggle('scrolled', window.scrollY > 54), { passive: true });
nav?.classList.toggle('scrolled', window.scrollY > 54);

document.querySelectorAll('.faq-list details').forEach((item) => {
  item.addEventListener('toggle', () => {
    if (!item.open) return;
    document.querySelectorAll('.faq-list details').forEach((other) => {
      if (other !== item) other.open = false;
    });
  });
});

document.querySelector('#estimate-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  const data = new FormData(form);
  const name = `${data.get('firstName')} ${data.get('lastName')}`.trim();
  const subject = encodeURIComponent(`Free estimate request from ${name}`);
  const body = encodeURIComponent([
    `Name: ${name}`,
    `Email: ${data.get('email')}`,
    `Phone: ${data.get('phone')}`,
    `Address: ${data.get('address') || 'Not provided'}`,
    '',
    `${data.get('message')}`
  ].join('\n'));
  document.querySelector('#form-note').textContent = 'Your email app is opening with your estimate request ready to send.';
  window.location.href = `mailto:john@greenscapestl.com?subject=${subject}&body=${body}`;
});

document.querySelector('#year').textContent = new Date().getFullYear();
