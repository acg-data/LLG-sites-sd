import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = normalize(join(dirname(fileURLToPath(import.meta.url)), '..'));
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.webp':'image/webp'};
const port = Number(process.env.PORT || 4173);

http.createServer(async (req, res) => {
  try {
    const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
    const requested = urlPath === '/' ? 'index.html' : urlPath.replace(/^\/+/, '');
    const path = normalize(join(root, requested));
    if (!path.startsWith(root)) throw new Error('Invalid path');
    const info = await stat(path);
    const finalPath = info.isDirectory() ? join(path, 'index.html') : path;
    const data = await readFile(finalPath);
    res.writeHead(200, {'Content-Type': mime[extname(finalPath)] || 'application/octet-stream'});
    res.end(data);
  } catch {
    const data = await readFile(join(root, 'index.html'));
    res.writeHead(404, {'Content-Type':'text/html; charset=utf-8'});
    res.end(data);
  }
}).listen(port, '127.0.0.1', () => console.log(`Local URL: http://127.0.0.1:${port}`));
