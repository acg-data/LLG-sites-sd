import { readFile, access } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const htmlFiles = ['index.html', 'thank-you.html'];
const requiredFiles = ['styles.css', 'script.js', 'assets/logo.png', 'assets/hero-retaining-wall.webp', 'assets/craftsmanship.webp', 'assets/og.webp'];

for (const file of [...htmlFiles, ...requiredFiles]) await access(resolve(root, file));

for (const file of htmlFiles) {
  const html = await readFile(resolve(root, file), 'utf8');
  if (!/^<!doctype html>/i.test(html.trim())) throw new Error(`${file} is not a complete HTML document.`);
  if (/href=["'][^"']*retainingwallcontractorsanantoniotx\.com/i.test(html)) throw new Error(`${file} links to the original domain.`);
  if (/Minuteman|Plumbing|Heating & Cooling/i.test(html)) throw new Error(`${file} contains old template branding.`);
}

console.log(`Static production build validated: ${htmlFiles.length} HTML pages and ${requiredFiles.length} required assets.`);
